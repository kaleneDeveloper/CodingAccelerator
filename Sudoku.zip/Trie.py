import sys
list_ = (sys.argv)
list_.sort()
list_.pop(-1)
list_ = " ".join(list_)
print(list_)


